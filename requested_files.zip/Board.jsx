import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { theme } from '../theme';

const ELEMENT_TYPES = {
    IMAGE: 'image',
    NOTE: 'note',
    TASK: 'task'
};

const COLORS = [
    { id: 'yellow', bg: '#FFF9C4', border: '#FBC02D' },
    { id: 'blue', bg: '#E3F2FD', border: '#1976D2' },
    { id: 'green', bg: '#E8F5E9', border: '#388E3C' },
    { id: 'red', bg: '#FFEBEE', border: '#D32F2F' },
    { id: 'purple', bg: '#F3E5F5', border: '#7B1FA2' }
];

const BoardElement = ({ element, onUpdate, onDelete, isEditMode }) => {
    const { t } = useTranslation();

    const handleDragEnd = (event, info) => {
        onUpdate(element.id, { x: element.x + info.offset.x, y: element.y + info.offset.y });
    };

    const toggleComplete = () => {
        if (element.type === ELEMENT_TYPES.TASK) {
            onUpdate(element.id, { completed: !element.completed });
        }
    };

    const colorConfig = COLORS.find(c => c.id === (element.color || 'yellow'));

    return (
        <motion.div
            drag={isEditMode}
            dragMomentum={false}
            onDragEnd={handleDragEnd}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1, x: element.x, y: element.y }}
            style={{
                position: 'absolute',
                width: element.width || 140,
                height: element.height || 140,
                cursor: isEditMode ? 'move' : 'default',
                zIndex: isEditMode ? 10 : 1,
            }}
        >
            <div style={{
                width: '100%',
                height: '100%',
                borderRadius: element.type === ELEMENT_TYPES.IMAGE ? '24px' : '16px',
                overflow: 'hidden',
                boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
                background: element.type === ELEMENT_TYPES.IMAGE ? '#fff' : colorConfig.bg,
                position: 'relative',
                border: isEditMode ? `2px solid ${colorConfig.border}` : `1px solid ${colorConfig.border}33`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: element.type === ELEMENT_TYPES.IMAGE ? '0' : '16px',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
            }}>
                {element.type === ELEMENT_TYPES.IMAGE ? (
                    <img src={element.content} alt="Dream" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : element.type === ELEMENT_TYPES.TASK ? (
                    <div onClick={toggleComplete} style={{ width: '100%', cursor: 'pointer' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                            <div style={{ width: '18px', height: '18px', borderRadius: '6px', border: `2px solid ${colorConfig.border}`, background: element.completed ? colorConfig.border : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                {element.completed && <span style={{ color: '#fff', fontSize: '10px', fontWeight: 900 }}>✓</span>}
                            </div>
                            <span style={{ fontSize: '10px', fontWeight: 800, color: colorConfig.border, textTransform: 'uppercase', letterSpacing: '1px' }}>{t('nav.workflow')}</span>
                        </div>
                        <div style={{ fontSize: '14px', fontWeight: 600, color: '#1a1a1a', textDecoration: element.completed ? 'line-through' : 'none', opacity: element.completed ? 0.6 : 1 }}>
                            {element.content}
                        </div>
                    </div>
                ) : (
                    <div style={{ fontSize: '15px', fontWeight: 600, color: '#1a1a1a', textAlign: 'center', width: '100%', lineHeight: '1.4' }}>
                        {element.content}
                    </div>
                )}

                {isEditMode && (
                    <button
                        onClick={() => onDelete(element.id)}
                        style={{ position: 'absolute', top: 8, right: 8, background: '#ff4d4d', color: '#fff', border: 'none', borderRadius: '50%', width: 24, height: 24, cursor: 'pointer', fontSize: 10, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 10px rgba(255,77,77,0.3)' }}
                    >
                        ✕
                    </button>
                )}
            </div>
        </motion.div>
    );
};

export default function Board() {
    const { t } = useTranslation();
    const [elements, setElements] = useState(() => {
        try {
            const saved = localStorage.getItem('dream_board_elements');
            return saved ? JSON.parse(saved) : [];
        } catch { return []; }
    });
    const [mode, setMode] = useState('vision');
    const [activeColor, setActiveColor] = useState('yellow');
    const [isEditMode, setIsEditMode] = useState(true);
    const boardRef = useRef(null);

    useEffect(() => {
        localStorage.setItem('dream_board_elements', JSON.stringify(elements));
    }, [elements]);

    const addElement = (type, content = '') => {
        const newEl = {
            id: Date.now().toString(),
            type,
            content: content || (type === ELEMENT_TYPES.NOTE ? 'Текст...' : type === ELEMENT_TYPES.TASK ? 'Задача...' : ''),
            x: 40 + Math.random() * 60,
            y: 40 + Math.random() * 60,
            width: 150,
            height: 150,
            color: activeColor,
            completed: false
        };
        setElements([...elements, newEl]);
    };

    const updateElement = (id, updates) => {
        setElements(elements.map(el => el.id === id ? { ...el, ...updates } : el));
    };

    const deleteElement = (id) => {
        setElements(elements.filter(el => el.id !== id));
    };

    const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file && file.size <= 3 * 1024 * 1024) {
            const reader = new FileReader();
            reader.onloadend = () => addElement(ELEMENT_TYPES.IMAGE, reader.result);
            reader.readAsDataURL(file);
        } else if (file) {
            alert(t('board.upload_help'));
        }
    };

    return (
        <div style={{ height: 'calc(100vh - 160px)', display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
            <div style={{ padding: '24px', position: 'relative', zIndex: 10, background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(15px)', borderBottom: '1px solid #f0f0f0' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                        <h2 style={{ margin: 0, fontSize: '26px', fontWeight: 900, color: '#1a1a1a', letterSpacing: '-0.5px' }}>{t('board.title')}</h2>
                        <div style={{ fontSize: '13px', color: '#888', marginTop: '2px', fontWeight: 500 }}>{t('board.subtitle')}</div>
                    </div>
                    <button
                        onClick={() => setIsEditMode(!isEditMode)}
                        style={{ padding: '10px 18px', borderRadius: '14px', border: 'none', background: isEditMode ? theme.colors.ui.primary : '#f5f5f5', color: isEditMode ? '#fff' : '#666', fontWeight: 700, fontSize: '13px', cursor: 'pointer', transition: 'all 0.2s' }}
                    >
                        {isEditMode ? '✨ Сохранить' : '⚙️ Настроить'}
                    </button>
                </div>

                <div style={{ display: 'flex', gap: '10px', marginTop: '20px', alignItems: 'center' }}>
                    <button
                        onClick={() => setMode(mode === 'vision' ? 'work' : 'vision')}
                        style={{ padding: '10px 16px', borderRadius: '12px', border: '1px solid #eee', background: '#fff', fontWeight: 700, fontSize: '12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}
                    >
                        {mode === 'vision' ? `🎨 ${t('board.mode_vision')}` : `🏗️ ${t('board.mode_work')}`}
                    </button>

                    <div style={{ width: '1px', height: '20px', background: '#eee', margin: '0 5px' }}></div>

                    {COLORS.map(c => (
                        <button
                            key={c.id}
                            onClick={() => setActiveColor(c.id)}
                            style={{
                                width: '24px',
                                height: '24px',
                                borderRadius: '50%',
                                background: c.bg,
                                border: `2px solid ${activeColor === c.id ? c.border : 'transparent'}`,
                                cursor: 'pointer',
                                transition: 'transform 0.2s',
                                transform: activeColor === c.id ? 'scale(1.2)' : 'scale(1)'
                            }}
                        />
                    ))}

                    <button
                        onClick={() => { if (confirm(t('board.clear') + '?')) setElements([]); }}
                        style={{ padding: '8px', borderRadius: '10px', border: 'none', background: '#FFF5F5', color: '#FF4D4D', cursor: 'pointer', marginLeft: 'auto' }}
                        title="Очистить всё"
                    >
                        🗑️
                    </button>
                </div>
            </div>

            <div
                ref={boardRef}
                style={{
                    flex: 1,
                    position: 'relative',
                    background: mode === 'vision' ? '#F8FAFC' : '#ffffff',
                    backgroundImage: mode === 'work' ? 'radial-gradient(#E2E8F0 1.5px, transparent 1.5px)' : 'none',
                    backgroundSize: '32px 32px',
                    overflow: 'auto',
                    touchAction: 'none'
                }}
            >
                {/* Zone Labels */}
                <div style={{ position: 'absolute', top: 20, left: 20, fontSize: '10px', fontWeight: 800, color: '#CBD5E1', textTransform: 'uppercase', letterSpacing: '2px', zIndex: 0 }}>WORK ZONE</div>
                <div style={{ position: 'absolute', bottom: 20, right: 20, fontSize: '10px', fontWeight: 800, color: '#CBD5E1', textTransform: 'uppercase', letterSpacing: '2px', zIndex: 0 }}>VISION ZONE</div>

                {elements.length === 0 && (
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94A3B8', textAlign: 'center', padding: '40px' }}>
                        <div>
                            <div style={{ fontSize: '64px', marginBottom: '20px', opacity: 0.3 }}>🗺️</div>
                            <div style={{ fontSize: '18px', fontWeight: 700, color: '#475569' }}>{t('board.empty')}</div>
                            <div style={{ fontSize: '14px', marginTop: '10px', color: '#94A3B8' }}>Расставь свои цели и задачи в свободном порядке</div>
                        </div>
                    </div>
                )}

                {elements.map(el => (
                    <BoardElement
                        key={el.id}
                        element={el}
                        isEditMode={isEditMode}
                        onUpdate={updateElement}
                        onDelete={deleteElement}
                    />
                ))}
            </div>

            <AnimatePresence>
                {isEditMode && (
                    <motion.div
                        initial={{ y: 100, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 100, opacity: 0 }}
                        style={{
                            position: 'absolute',
                            bottom: 24,
                            left: '50%',
                            transform: 'translateX(-50%)',
                            background: 'rgba(255,255,255,0.95)',
                            backdropFilter: 'blur(20px)',
                            padding: '10px 14px',
                            borderRadius: '24px',
                            boxShadow: '0 20px 50px rgba(0,0,0,0.15)',
                            display: 'flex',
                            gap: '10px',
                            zIndex: 100,
                            border: '1px solid rgba(255,255,255,0.5)',
                            width: 'fit-content'
                        }}
                    >
                        <input type="file" id="board-img-upload" accept="image/*" style={{ display: 'none' }} onChange={handleImageUpload} />
                        <label htmlFor="board-img-upload" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '44px', height: '44px', cursor: 'pointer', background: theme.colors.ui.primary, color: '#fff', borderRadius: '16px', fontSize: '20px', boxShadow: `0 8px 15px ${theme.colors.ui.primary}44` }}>
                            🖼️
                        </label>
                        <button
                            onClick={() => {
                                const txt = prompt('Текст заметки?');
                                if (txt) addElement(ELEMENT_TYPES.NOTE, txt);
                            }}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '44px', height: '44px', cursor: 'pointer', background: '#fff', border: '1px solid #eee', borderRadius: '16px', fontSize: '20px' }}
                            title="Добавить заметку"
                        >
                            📝
                        </button>
                        <button
                            onClick={() => {
                                const txt = prompt('Что нужно сделать?');
                                if (txt) addElement(ELEMENT_TYPES.TASK, txt);
                            }}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minWidth: '100px', height: '44px', cursor: 'pointer', background: '#fff', border: '1px solid #eee', borderRadius: '16px', fontSize: '14px', padding: '0 16px', fontWeight: 800, color: theme.colors.ui.primary }}
                        >
                            + Задача
                        </button>

                        <div style={{ width: '1px', height: '30px', background: '#eee', margin: '0 4px' }}></div>

                        <button
                            onClick={() => alert('Режим связей: Скоро!')}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '44px', height: '44px', cursor: 'pointer', background: '#fff', border: '1px solid #eee', borderRadius: '16px', fontSize: '20px' }}
                            title="Режим связей"
                        >
                            🔗
                        </button>
                        <button
                            onClick={() => alert('Голосовая заметка: Скоро!')}
                            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '44px', height: '44px', cursor: 'pointer', background: '#fff', border: '1px solid #eee', borderRadius: '16px', fontSize: '20px' }}
                            title="Голосовая запись"
                        >
                            🎙️
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
