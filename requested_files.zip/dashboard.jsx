import React from 'react';
import { theme } from '../theme';

export const dashboardConfig = [
    {
        id: 'habits1',
        name: 'nav.habits',
        icon: '🏃',
        position: {
            desktop: { x: '5%', y: '40%', width: '130px', height: '130px', shape: '42% 58% 70% 30% / 45% 45% 55% 55%' },
            mobile: { x: '2%', y: '38%', width: '115px', height: '115px', shape: '42% 58% 70% 30% / 45% 45% 55% 55%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ color: theme.colors.text.secondary, marginBottom: '4px' }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                </div>
                <div style={{ fontWeight: 700, fontSize: '13px', color: theme.colors.text.primary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.habits')}</div>
                <div style={{ fontSize: '15px', color: theme.colors.text.muted, fontWeight: 500 }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'goals',
        name: 'nav.workflow',
        icon: '🎯',
        position: {
            desktop: { x: '62%', y: '42%', width: '125px', height: '125px', shape: '58% 42% 47% 53% / 55% 60% 40% 45%' },
            mobile: { x: '65%', y: '40%', width: '110px', height: '110px', shape: '58% 42% 47% 53% / 55% 60% 40% 45%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ color: theme.colors.text.secondary, marginBottom: '2px' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path></svg>
                </div>
                <div style={{ fontWeight: 700, fontSize: '13px', color: theme.colors.text.primary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.workflow')}</div>
                <div style={{ fontSize: '15px', color: theme.colors.text.muted, fontWeight: 600 }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'finance',
        name: 'nav.finance',
        icon: '💰',
        position: {
            desktop: { x: '24%', y: '52%', width: '230px', height: '230px', shape: '50%', zIndex: 10 },
            mobile: { x: '12%', y: '50%', width: '190px', height: '190px', shape: '50%', zIndex: 10 }
        },
        renderContent: (progress, t) => {
            const isMobile = window.innerWidth < 768;
            const size = isMobile ? 150 : 180;
            const strokeWidth = 12;
            const radius = (size - strokeWidth) / 2;
            const circumference = radius * 2 * Math.PI;
            const offset = circumference - (progress / 100) * circumference;
            return (
                <div style={{ position: 'relative', width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
                        <circle stroke="#f5f5f5" strokeWidth={strokeWidth} fill="transparent" r={radius} cx={size / 2} cy={size / 2} />
                        <circle stroke={theme.colors.ui.primary} strokeWidth={strokeWidth} fill="transparent" strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" r={radius} cx={size / 2} cy={size / 2} style={{ transition: 'stroke-dashoffset 0.8s ease-out' }} />
                    </svg>
                    <div style={{ position: 'absolute', textAlign: 'center', width: '80%', overflow: 'hidden' }}>
                        <div style={{ fontSize: '18px', fontWeight: 800, color: theme.colors.text.primary, lineHeight: '1.2' }}>{t('nav.finance')}</div>
                        <div style={{ fontSize: '16px', fontWeight: 600, color: theme.colors.text.primary, opacity: 0.7 }}>{progress}%</div>
                    </div>
                </div>
            );
        }
    },
    {
        id: 'goals2',
        name: 'nav.projects',
        icon: '🌟',
        position: {
            desktop: { x: '5%', y: '86%', width: '115px', height: '115px', shape: '35% 65% 60% 40% / 40% 40% 60% 60%' },
            mobile: { x: '0%', y: '84%', width: '105px', height: '105px', shape: '35% 65% 60% 40% / 40% 40% 60% 60%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ color: theme.colors.text.secondary, marginBottom: '4px' }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.27 1.27L3 12l5.813 1.912a2 2 0 0 1 1.27 1.27L12 21l1.912-5.813a2 2 0 0 1 1.27-1.27L21 12l-5.813-1.912a2 2 0 0 1-1.27-1.27L12 3Z" /></svg>
                </div>
                <div style={{ fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.projects')}</div>
                <div style={{ fontSize: '16px', color: theme.colors.text.secondary, fontWeight: 600 }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'projects',
        name: 'nav.skills',
        icon: '💼',
        position: {
            desktop: { x: '45%', y: '95%', width: '110px', height: '100px', shape: '45% 55% 40% 60% / 60% 40% 60% 40%' },
            mobile: { x: '35%', y: '93%', width: '100px', height: '90px', shape: '45% 55% 40% 60% / 60% 40% 60% 40%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.skills')}</div>
                <div style={{ fontWeight: 800, fontSize: '16px', color: theme.colors.ui.primary }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'habits2',
        name: 'nav.habits',
        icon: '📎',
        position: {
            desktop: { x: '72%', y: '86%', width: '110px', height: '110px', shape: '50%' },
            mobile: { x: '72%', y: '84%', width: '100px', height: '100px', shape: '50%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ marginBottom: '4px' }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 8v8"></path><path d="M8 12h8"></path></svg>
                </div>
                <div style={{ fontSize: '11px', fontWeight: 600, color: theme.colors.text.primary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.habits')}</div>
                <div style={{ fontSize: '15px', fontWeight: 800, color: theme.colors.text.primary }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'ucek',
        name: 'nav.social',
        icon: '👥',
        position: {
            desktop: { x: '12%', y: '108%', width: '125px', height: '125px', shape: '40% 60% 70% 30% / 50% 50% 50% 50%' },
            mobile: { x: '5%', y: '106%', width: '110px', height: '110px', shape: '40% 60% 70% 30% / 50% 50% 50% 50%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden' }}>
                <div style={{ display: 'flex', gap: '4px', marginBottom: '4px', justifyContent: 'center' }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="2.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                    <span style={{ fontWeight: 700, fontSize: '14px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.social')}</span>
                </div>
                <div style={{ fontSize: '16px', fontWeight: 600, color: theme.colors.text.secondary }}>{progress}%</div>
            </div>
        )
    },
    {
        id: 'bugerols',
        name: 'nav.skills',
        icon: '🔍',
        position: {
            desktop: { x: '62%', y: '108%', width: '115px', height: '105px', shape: '60% 40% 30% 70% / 60% 30% 70% 40%' },
            mobile: { x: '68%', y: '106%', width: '100px', height: '90px', shape: '60% 40% 30% 70% / 60% 30% 70% 40%' }
        },
        renderContent: (progress, t) => (
            <div style={{ textAlign: 'center', width: '90%', overflow: 'hidden', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', justifyContent: 'center', marginBottom: '2px' }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <div style={{ fontSize: '14px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t('nav.skills')}</div>
                </div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: theme.colors.text.secondary }}>{progress}%</div>
            </div>
        )
    }
];
