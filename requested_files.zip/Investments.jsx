import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { theme } from '../theme';
import Modal from './Modal';
import HistoryModal from './HistoryModal';
import ProgressChart from './ProgressChart';

const ICONS = ['❤️', '🧠', '🤝', '💼', '🧘', '🎨', '✈️', '🏠', '💰', '🎵', '📚', '⚽', '🌿', '🎁', '⭐', '🔥'];

const CircularProgress = ({ percentage, size, strokeWidth, color, label }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div style={{ position: 'relative', width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
                <circle stroke="#eee" strokeWidth={strokeWidth} fill="transparent" r={radius} cx={size / 2} cy={size / 2} />
                <circle
                    stroke={color}
                    strokeWidth={strokeWidth}
                    fill="transparent"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    r={radius}
                    cx={size / 2}
                    cy={size / 2}
                    style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                />
            </svg>
            <div style={{ position: 'absolute', textAlign: 'center' }}>
                <div style={{ fontSize: size / 5, fontWeight: 700, color: theme.colors.text.primary }}>{percentage}%</div>
                {label && <div style={{ fontSize: size / 10, color: theme.colors.text.secondary }}>{label}</div>}
            </div>
        </div>
    );
};

export default function Investments() {
    const { t } = useTranslation();
    const [assets, setAssets] = useState(() => {
        try {
            const saved = localStorage.getItem('lifeInvestments');
            return saved ? JSON.parse(saved) : [
                { id: 'health', name: t('investments.health') || 'Здоровье', icon: '❤️', progress: 65, dividends: '+Energy' },
                { id: 'skills', name: t('investments.skills') || 'Навыки', icon: '🧠', progress: 40, dividends: '+Level Up' },
                { id: 'relations', name: t('investments.relations') || 'Отношения', icon: '🤝', progress: 80, dividends: '+Joy' },
                { id: 'finance', name: t('investments.finance') || 'Профит', icon: '💼', progress: 55, dividends: '+Freedom' },
                { id: 'faith', name: t('investments.faith') || 'Вера', icon: '🧘', progress: 30, dividends: '+Peace' },
            ];
        } catch {
            return [];
        }
    });

    const [activeModal, setActiveModal] = useState(null);
    const [historyModal, setHistoryModal] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [selectedIcon, setSelectedIcon] = useState(ICONS[0]);

    useEffect(() => {
        localStorage.setItem('lifeInvestments', JSON.stringify(assets));
    }, [assets]);

    const totalProgress = useMemo(() => {
        if (assets.length === 0) return 0;
        const sum = assets.reduce((acc, curr) => acc + curr.progress, 0);
        return Math.round(sum / assets.length);
    }, [assets]);

    const handleInvest = (amount) => {
        if (!activeModal?.data) return;
        setAssets(assets.map(a => {
            if (a.id === activeModal.data) {
                const newProgress = Math.min(100, a.progress + amount);
                return { ...a, progress: newProgress };
            }
            return a;
        }));
        closeModal();
    };

    const handleCreateAsset = () => {
        if (!inputValue.trim()) return;
        const newAsset = {
            id: Date.now().toString(),
            name: inputValue,
            icon: selectedIcon,
            progress: 0,
            dividends: '+Future'
        };
        setAssets([...assets, newAsset]);
        closeModal();
    };

    const closeModal = () => {
        setActiveModal(null);
        setInputValue('');
    };

    return (
        <div style={{ padding: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '32px' }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: '28px', color: theme.colors.text.primary }}>{t('investments.title')}</h2>
                    <div style={{ color: theme.colors.text.secondary }}>{t('investments.roi')}</div>
                </div>
                <CircularProgress percentage={totalProgress} size={80} strokeWidth={8} color="#4CAF50" />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', paddingBottom: '80px' }}>
                {assets.map(asset => (
                    <div key={asset.id} style={{
                        background: '#fff',
                        borderRadius: theme.radii.card,
                        padding: '16px',
                        boxShadow: theme.shadows.card,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        position: 'relative',
                        overflow: 'hidden',
                        transition: 'transform 0.2s',
                        cursor: 'default'
                    }}
                        onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.02)'}
                        onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
                    >
                        <div style={{ fontSize: '32px', marginBottom: '8px' }}>{asset.icon}</div>

                        <div
                            onClick={() => setHistoryModal(asset)}
                            style={{
                                position: 'absolute', top: '10px', right: '10px',
                                cursor: 'pointer', opacity: 0.5
                            }}>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                        </div>

                        <div style={{ fontWeight: 600, fontSize: '16px', color: theme.colors.text.primary, textAlign: 'center' }}>{asset.name}</div>
                        <div style={{ fontSize: '12px', color: '#4CAF50', marginBottom: '12px', fontWeight: 500 }}>{asset.dividends}</div>

                        <div style={{ width: '100%', height: '6px', background: '#f0f0f0', borderRadius: '3px', marginBottom: '16px' }}>
                            <div style={{ width: `${asset.progress}%`, height: '100%', background: '#4CAF50', borderRadius: '3px', transition: 'width 0.5s' }}></div>
                        </div>

                        <button
                            onClick={() => setActiveModal({ type: 'invest', data: asset.id })}
                            style={{
                                width: '100%',
                                padding: '8px',
                                borderRadius: '12px',
                                border: 'none',
                                background: '#E8F5E9',
                                color: '#2E7D32',
                                fontWeight: 600,
                                cursor: 'pointer',
                                fontSize: '13px'
                            }}>
                            {t('investments.invest')}
                        </button>
                    </div>
                ))}

                <button
                    onClick={() => setActiveModal({ type: 'new' })}
                    style={{
                        background: 'transparent',
                        borderRadius: theme.radii.card,
                        border: '2px dashed #ddd',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                        minHeight: '180px',
                        cursor: 'pointer',
                        color: '#999'
                    }}>
                    <div style={{ fontSize: '24px', marginBottom: '4px' }}>+</div>
                    <div>{t('investments.new')}</div>
                </button>
            </div>

            <Modal
                isOpen={!!activeModal}
                onClose={closeModal}
                title={activeModal?.type === 'new' ? t('investments.modal_create') : t('investments.modal_invest')}
                footer={null}
            >
                {activeModal?.type === 'new' ? (
                    <div>
                        <div style={{ marginBottom: '16px' }}>
                            <label style={{ display: 'block', fontSize: '12px', color: '#666', marginBottom: '8px' }}>Choose Icon</label>
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '8px' }}>
                                {ICONS.map(icon => (
                                    <button
                                        key={icon}
                                        onClick={() => setSelectedIcon(icon)}
                                        style={{
                                            background: selectedIcon === icon ? '#e3f2fd' : 'transparent',
                                            border: selectedIcon === icon ? '2px solid #2196f3' : '1px solid #eee',
                                            borderRadius: '8px',
                                            cursor: 'pointer',
                                            fontSize: '20px',
                                            padding: '4px'
                                        }}
                                    >
                                        {icon}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <input
                            autoFocus
                            placeholder="Name..."
                            value={inputValue}
                            onChange={e => setInputValue(e.target.value)}
                            style={{ width: '100%', padding: '12px', borderRadius: '12px', border: '1px solid #eee', fontSize: '16px', marginBottom: '16px' }}
                        />
                        <button onClick={handleCreateAsset} style={{ width: '100%', padding: '12px', background: theme.colors.ui.primary, color: 'white', borderRadius: '12px', border: 'none', fontWeight: 600 }}>{t('investments.create')}</button>
                    </div>
                ) : (
                    <div style={{ textAlign: 'center' }}>
                        <p style={{ color: theme.colors.text.secondary, marginBottom: '24px', fontWeight: 600 }}>{t('investments.effort_level')}</p>
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                            <button onClick={() => handleInvest(5)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 20px', borderRadius: '16px', border: '1px solid #4CAF50', background: 'white', color: '#4CAF50', fontWeight: 700 }}>
                                <span style={{ fontSize: '12px', opacity: 0.8 }}>{t('investments.small_step')}</span>
                                <span>+5%</span>
                            </button>
                            <button onClick={() => handleInvest(15)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 20px', borderRadius: '16px', border: 'none', background: '#4CAF50', color: 'white', fontWeight: 700 }}>
                                <span style={{ fontSize: '12px', opacity: 0.8 }}>{t('investments.significant')}</span>
                                <span>+15%</span>
                            </button>
                        </div>
                    </div>
                )}
            </Modal>

            <HistoryModal
                isOpen={!!historyModal}
                onClose={() => setHistoryModal(null)}
                title={historyModal?.name ? `${historyModal.name} history` : 'history'}
            />
        </div>
    );
}

import { useMemo } from 'react';
